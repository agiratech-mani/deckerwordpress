<?php

namespace EasingSlider\Foundation\Contracts\Admin\ListTables;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface ListTable
{
	//
}
