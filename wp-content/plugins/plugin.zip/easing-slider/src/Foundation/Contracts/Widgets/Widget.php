<?php

namespace EasingSlider\Foundation\Contracts\Widgets;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface Widget
{
	//
}
