=== Div Shortcode ===
Contributors: billerickson, deanpence
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=4BJ57JH34CA7A
Tags: shortcode, div, columns
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 2.1

Allows you to create a div by using the shortcodes [div] and [end-div]. 

== Description ==

Allows you to create a div by using the shortcodes [div] and [end-div]. To add an id of "foo" and class of "bar", use [div id="foo" class="bar"].

**No support will be provided by the developer**

== Changelog ==

= 2.1 = 
* People are still having issues with the new version and we aren't able to replicate to fix them. I'm reverting back to the original code in 1.0. Sorry for all the updates.

= 2.0.1 =
* Some people have reported issues with the shortcode no longer working. This (hopefully) fixes it.

= 2.0 =
* Completely rebuilt by Dean Hall using pseudo-shortcodes. Content is actually stored as html, so if you disable the plugin the div's still work.


= 1.0 =
* Release of plugin

