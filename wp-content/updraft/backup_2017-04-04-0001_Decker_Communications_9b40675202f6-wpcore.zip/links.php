<!DOCTYPE html>

<html>
<head>
<title>Decker Video Links</title></head>
<body>
<p>FLV links: <br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_3x3.flv">http://decker.com/wp-content/uploads/2012/07/flashvideo_3x3.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/ChipHeathFinal.flv">http://decker.com/wp-content/uploads/2012/06/ChipHeathFinal.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/before-after-1.flv">http://decker.com/wp-content/uploads/2012/06/before-after-1.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/before-after-2.flv">http://decker.com/wp-content/uploads/2012/06/before-after-2.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/before-after-3.flv">http://decker.com/wp-content/uploads/2012/06/before-after-3.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/before-after-4.flv">http://decker.com/wp-content/uploads/2012/06/before-after-4.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/before-after-5.flv">http://decker.com/wp-content/uploads/2012/06/before-after-5.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_clendening.flv">http://decker.com/wp-content/uploads/2012/07/flashvideo_clendening.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_smerklo.flv">http://decker.com/wp-content/uploads/2012/07/flashvideo_smerklo.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_geren.flv">http://decker.com/wp-content/uploads/2012/07/flashvideo_geren.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_osgood.flv">http://decker.com/wp-content/uploads/2012/07/flashvideo_osgood.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/flashvideo_keim.flv">http://decker.com/wp-content/uploads/2012/06/flashvideo_keim.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_brusseau.flv">http://decker.com/wp-content/uploads/2012/07/flashvideo_brusseau.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_nelson.flv">http://decker.com/wp-content/uploads/2012/07/flashvideo_nelson.flv</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/flashvideo_decker.flv">http://decker.com/wp-content/uploads/2012/06/flashvideo_decker.flv</a><br />
</p>
<p>
MP4 format videos:<br />
<a href="http://decker.com/wp-content/uploads/2012//06/Ben-Decker-DRT-Long.mp4">http://decker.com/wp-content/uploads/2012/06/Ben-Decker-DRT-Long.mp4</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/B-K-Speaking-V2-edited.mp4">http://decker.com/wp-content/uploads/2012/06/B-K-Speaking-V2-edited.mp4</a><br />
<a href="http://decker.com/wp-content/uploads/2012/06/Kelly-Decker-LONG-v3.mp4">http://decker.com/wp-content/uploads/2012/06/Kelly-Decker-LONG-v3.mp4</a><br />
<a href="http://decker.com/wp-content/uploads/2012//06/Kelly-Decker-SHORT-v3.mp4">http://decker.com/wp-content/uploads/2012/06/Kelly-Decker-SHORT-v3.mp4</a><br />
</p>

<p>M4V format video:<br />
<a href="http://decker.com/wp-content/uploads/2010/04/Up-in-the-Air-Clooney.m4v">http://decker.com/wp-content/uploads/2010/04/Up-in-the-Air-Clooney.m4v</a><br />
</p>

<p>
WMV format video:<br />
<a href="http://decker.com/wp-content/uploads/2012/07/flashvideo_3x3.flv">http://decker.com/wp-content/uploads/2009/10/Gestures-Comp.wmv</a><br />
   </p>
</body>
</html>