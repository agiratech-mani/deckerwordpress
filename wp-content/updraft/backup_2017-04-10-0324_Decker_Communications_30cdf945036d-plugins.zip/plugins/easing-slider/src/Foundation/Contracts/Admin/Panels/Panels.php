<?php

namespace EasingSlider\Foundation\Contracts\Admin\Panels;

/**
 * Exit if accessed directly
 */
if ( ! defined('ABSPATH')) {
	exit;
}

interface Panels
{
	//
}
